/*
  샘플 스토리 데이터 (1주차 라이브 데모용).
  editor.html에서 "가져오기"로 이 파일을 열어 구조를 그대로 살펴볼 수 있습니다.
  images/videos 폴더에 실제 이미지가 없으면 화면에 이미지가 깨져 보이는 게 정상입니다
  (gameaify로 만든 실제 이미지를 넣으면 채워집니다).
*/
window.STORY_DATA = {
  "meta": {
    "title": "서울, 2033",
    "author": "샘플",
    "styleTag": "다크 사이버펑크, 채도 낮은 네온톤, 디지털 페인팅 스타일"
  },
  "stats": { "체력": 100, "정신력": 100 },
  "startScene": "start",
  "classes": [
    {
      "id": "hacker",
      "name": "해커",
      "description": "정신력이 높고, 해킹 관련 선택지를 더 열 수 있다.",
      "startingStats": { "정신력": 120 }
    },
    {
      "id": "survivor",
      "name": "생존자",
      "description": "체력이 높고, 전투/생존 관련 선택지에 유리하다.",
      "startingStats": { "체력": 130 }
    }
  ],
  "items": [
    {
      "id": "knife",
      "name": "녹슨 생존용 칼",
      "icon": "item_knife.png",
      "effect": { "체력": 5 }
    },
    {
      "id": "keycard",
      "name": "출입 카드",
      "icon": "item_keycard.png",
      "effect": {}
    }
  ],
  "skills": [
    {
      "id": "hack",
      "name": "해킹",
      "icon": "skill_hack.png",
      "requires": { "class": "hacker" }
    }
  ],
  "scenes": {
    "start": {
      "image": "scene_start.png",
      "video": null,
      "text": "2033년, 서울. 정전이 사흘째 이어지고 있다. 당신은 무너진 아파트 복도에 서 있다.",
      "choices": [
        { "label": "비상계단으로 내려간다", "next": "scene_stairs" },
        { "label": "옆집 문을 두드려본다", "next": "scene_neighbor" }
      ]
    },
    "scene_stairs": {
      "image": "scene_stairs.png",
      "text": "계단은 어둡고 가파르다. 내려가는 중 녹슨 칼 하나를 발견했다.",
      "choices": [
        { "label": "칼을 챙긴다", "next": "scene_lobby", "grantItem": "knife" },
        { "label": "그냥 지나친다", "next": "scene_lobby" }
      ]
    },
    "scene_neighbor": {
      "image": "scene_neighbor.png",
      "text": "옆집 문이 살짝 열려 있다. 안에서 출입 카드 하나를 발견했다.",
      "choices": [
        { "label": "카드를 챙긴다", "next": "scene_lobby", "grantItem": "keycard", "effects": { "정신력": -5 } },
        { "label": "그냥 나온다", "next": "scene_lobby" }
      ]
    },
    "scene_lobby": {
      "image": "scene_lobby.png",
      "text": "1층 로비. 비상구 옆에 잠긴 서버실 문이 보인다.",
      "choices": [
        {
          "label": "출입 카드로 서버실 문을 연다",
          "next": "ending_hack",
          "requires": { "item": "keycard" }
        },
        {
          "label": "해킹으로 문을 강제로 연다",
          "next": "ending_hack",
          "requires": { "class": "hacker" }
        },
        { "label": "밖으로 나간다", "next": "ending_escape" }
      ]
    },
    "ending_hack": {
      "image": "scene_server.png",
      "text": "서버실 안에서 통신 장비를 찾아 외부와 연결하는 데 성공했다.",
      "choices": []
    },
    "ending_escape": {
      "image": "scene_outside.png",
      "text": "건물 밖으로 나왔다. 도시는 여전히 어둡지만, 당신은 살아남았다.",
      "choices": []
    }
  },
  "endings": {
    "ending_good": {
      "sceneId": "ending_hack",
      "title": "구조 신호",
      "video": null
    },
    "ending_normal": {
      "sceneId": "ending_escape",
      "title": "생존",
      "video": null
    }
  }
};
